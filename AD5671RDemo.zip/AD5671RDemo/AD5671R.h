#ifndef _AD5671R_H
#define _AD5671R_H


#include "Arduino.h"
#include <Wire.h>

// I2C Address
#define AD5671R_DAC_A    (0b0000)
#define AD5671R_DAC_B    (0b0001)
#define AD5671R_DAC_C    (0b0010)
#define AD5671R_DAC_D    (0b0011)

#define AD5671R_SHIFT    4       //<  shift 12 bit values by 4 bit to become 16 bit

// DAC Channel addresses
#define AD5671R_CH_0    (0b0000)   //< DAC0 channel address
#define AD5671R_CH_1    (0b0001)   //< DAC1 channel address
#define AD5671R_CH_2    (0b0010)   //< DAC2 channel address
#define AD5671R_CH_3    (0b0011)   //< DAC3 channel address
#define AD5671R_CH_4    (0b0100)   //< DAC4 channel address
#define AD5671R_CH_5    (0b0101)   //< DAC5 channel address
#define AD5671R_CH_6    (0b0110)   //< DAC6 channel address
#define AD5671R_CH_7    (0b0111)   //< DAC7 channel address


// Commands
#define AD5671R_CMD_NOOP                    (0b0000) //< No operation
#define AD5671R_CMD_WRITE_INPUT_N           (0b0001) //< Write to Input Register n (depend on LDAC)
#define AD5671R_CMD_UPDATE_DAC_RG_N         (0b0010) //< Update DAC Register n with contents of Iput Register n
#define AD5671R_CMD_WRITE_UPDATE_DAC_CH_N   (0b0011) //< Write to and update DAC Channel n
#define AD5671R_CMD_POWER_DOWN_UP_DAC       (0b0100) //< Power down/ power up DAC
#define AD5671R_CMD_LDAC_MASK               (0b0101) //< Hardware LDAC mask register
#define AD5671R_CMD_RESET                   (0b0110) //< Software reset (power-on reset)
#define AD5671R_CMD_INTERNAL_REFER_SETUP    (0b0111) //< Internal reference and gain setup register

#define AD5671R_CMD_READBACK_ENABLE         (0b1001) //< Set up the readback register (readback enable)
#define AD5671R_CMD_UPDATE_ALL_INPUT_RG     (0b1010) //< Update all channels of input register simultaneously with the input data 
#define AD5671R_CMD_UPDATE_ALL_INPUT_DAC_RG (0b1011) //< Update all channels of DAC register and input register simultaneously with the input data 

// Modes of operation
#define  AD5671R_STATE_NORMAL      (0b0000)
#define  AD5671R_STATE_GND1k       (0b0001)
#define  AD5671R_STATE_TRISTATE    (0b0011)

#define  AD5671R_ADDR_MSB (0b0001100)  //7 BIT ADDRESS FIRST FIVE MSB 00011 << 2

#define  LDAC_Mask      (0b0001)     //< LDAC set HIGH.  DAC channels are updated. (DAC channels see LDAC pin as 1.)
#define  LDAC_NoMask    (0b0000)     //< LDAC as  LDAC_PIN. Determined by the LDAC pin.

#define  REF_ON   0
#define  REF_OFF  1

#define  GAIN_1   0
#define  GAIN_2   1

class AD5671R{
 public:
  AD5671R();
  void begin();
  void setDAC(uint8_t addr, uint8_t channel, uint8_t operation, uint16_t value);
  void readDAC(uint8_t addr, uint8_t channel, uint8_t operation, uint16_t *returnArray);
  void setPowerState(uint8_t addr, uint8_t DAC7_State, uint8_t DAC6_State, 
                            uint8_t DAC5_State, uint8_t DAC4_State,
                            uint8_t DAC3_State, uint8_t DAC2_State, 
                            uint8_t DAC1_State, uint8_t DAC0_State);
  void setLDACMask(uint8_t addr, uint8_t channel);
  void setLDACMask(uint8_t addr, uint8_t DAC7_Mask, uint8_t DAC6_Mask, 
                          uint8_t DAC5_Mask, uint8_t DAC4_Mask,
                          uint8_t DAC3_Mask, uint8_t DAC2_Mask, 
                          uint8_t DAC1_Mask, uint8_t DAC0_Mask);
  void reset(uint8_t addr);
  void setGain(uint8_t addr, uint8_t gain, uint8_t interref);

};

#endif
