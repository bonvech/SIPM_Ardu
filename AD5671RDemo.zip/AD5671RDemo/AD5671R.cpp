/**************************************************************************/
/*!
    @file     AD5671R.cpp 
    @author   E.A. Bonvech on the base on the A. Cooper (Isotopash) project 
    @license  None (see license.txt)

	This is a library for the AD5671R 8 Channel I2C DAC
	----> https://mouser.com/ProductDetail/584-AD5671RBRUZ

  I2C Address
  name    addr    A1    A0  (pins)
  DAC_A     0     GND   GND
  DAC_B     1     GND   V
  DAC_C     2     V     GND
  DAC_D     3     V     V

 i2c address is 7 bit. 5 Most Significant Bits are 00011. The last 2 Bits
 are the address given by A1 and A0 address pins.


	@section  HISTORY

    v1.0  - First release
*/
/**************************************************************************/
#include "Arduino.h"
#include <Wire.h>

#include "AD5671R.h"


/**************************************************************************/
/*!
    @brief  Abstract away platform differences in Arduino wire library
*/
/**************************************************************************/
static uint8_t i2cread(void) 
{
    return Wire.read();
}


/**************************************************************************/
/*!
    @brief  Abstract away platform differences in Arduino wire library
*/
/**************************************************************************/
static void i2cwrite(uint8_t x) 
{
    Wire.write((uint8_t)x);
}


/**************************************************************************/
/*!
    @brief  Returns number of bits set to 1 in an 8-bit byte.
*/
/**************************************************************************/
static uint8_t countSetBits(uint8_t n)
{
    uint8_t count = 0;
    while (n)
    {
        count += n & 1;
        n >>= 1;
    }
    return count;
}


/**************************************************************************/
/*!
    @brief  Instantiates a new AD5671R class
*/
/**************************************************************************/
AD5671R::AD5671R() 
{
}


/**************************************************************************/
/*!
    @brief  Setups the HW
*/
/**************************************************************************/
void AD5671R::begin() 
{
    Wire.begin();
}


/**************************************************************************/
/*!
    @brief  Sets the output voltage to a fraction of source vref.  (Value
            can be 0..65,536)
    @param[in]  addr
                                                                            A1    A0  (pins)    7 bit addr
                AD5671R_DAC_A                       or  0               :   GND   GND           0x08
                AD5671R_DAC_B                       or  1               :   GND   V             0x09
                AD5671R_DAC_C                       or  2               :   V     GND           0x0A
                AD5671R_DAC_D                       or  3               :   V     V             0x0B
    @param[in]  channel
                AD5671R_CH_0                        or  0  or   0b0000  :  DAC0 channel selected
                AD5671R_CH_1                        or  1  or   0b0001  :  DAC1 channel selected
                AD5671R_CH_2                        or  2  or   0b0010  :  DAC2 channel selected
                AD5671R_CH_3                        or  3  or   0b0011  :  DAC3 channel selected
                AD5671R_CH_4                        or  4  or   0b0100  :  DAC4 channel selected
                AD5671R_CH_5                        or  5  or   0b0101  :  DAC5 channel selected
                AD5671R_CH_6                        or  6  or   0b0110  :  DAC6 channel selected
                AD5671R_CH_7                        or  7  or   0b0111  :  DAC7 channel selected
    @param[in]  operation
                AD5671R_CMD_NOOP                    or  0  or  (0b0000) : No operation
                AD5671R_CMD_WRITE_INPUT_N           or  1  or  (0b0001) : Write to Input Register n (depend on LDAC)
                AD5671R_CMD_UPDATE_DAC_RG_N         or  2  or  (0b0010) : Update DAC Register n with contents of Iput Register n
                AD5671R_CMD_WRITE_UPDATE_DAC_CH_N   or  3  or  (0b0011) : Write to and update DAC Channel "channel n"
                AD5671R_CMD_POWER_DOWN_UP_DAC       or  4  or  (0b0100) : Power down/ power up DAC
                AD5671R_CMD_LDAC_MASK               or  5  or  (0b0101) : Hardware LDAC mask register
                AD5671R_CMD_RESET                   or  6  or  (0b0110) : Software reset (power-on reset)
                AD5671R_CMD_INTERNAL_REFER_SETUP    or  7  or  (0b0111) : Internal reference and gain setup register
                AD5671R_CMD_READBACK_ENABLE         or  9  or  (0b1001) : Set up the readback register (readback enable)
                AD5671R_CMD_UPDATE_ALL_INPUT_RG     or 10  or  (0b1010) : Update all channels of input register simultaneously with the input data 
                AD5671R_CMD_UPDATE_ALL_INPUT_DAC_RG or 11  or  (0b1011) : Update all channels of DAC register and input register simultaneously with the input data 
    @param[in]  value
                The 16-bit value representing the relationship between
                the DAC's input voltage and its output voltage.
*/
/**************************************************************************/
void AD5671R::setDAC(uint8_t addr, uint8_t channel, uint8_t operation, uint16_t value)
{
    // Start I2C transmission
    Wire.beginTransmission(AD5671R_ADDR_MSB + addr);
    // Command And Channel
    i2cwrite((operation << 4) + (channel));

    // Shift 4 bits
    value = value << AD5671R_SHIFT;

    //Split 16 bit into two 8 Bits
    i2cwrite(value >> 8);     //MSB
    i2cwrite(value & 0x00FF); //LSB

    // Stop I2C transmission
    Wire.endTransmission();
}


/**************************************************************************/
/*!
    @brief  Gets the output voltage to a fraction of source vref.  (Value
            can be 0..65,536)
    @param[in]  addr
                                                                            A1    A0  (pins)    7 bit addr
                AD5671R_DAC_A                       or  0               :   GND   GND           0x08
                AD5671R_DAC_B                       or  1               :   GND   V             0x09
                AD5671R_DAC_C                       or  2               :   V     GND           0x0A
                AD5671R_DAC_D                       or  3               :   V     V             0x0B
    @param[in]  channel
                AD5671R_CH_0                        or  0  or   0b0000  :  DAC0 channel selected
                AD5671R_CH_1                        or  1  or   0b0001  :  DAC1 channel selected
                AD5671R_CH_2                        or  2  or   0b0010  :  DAC2 channel selected
                AD5671R_CH_3                        or  3  or   0b0011  :  DAC3 channel selected
                AD5671R_CH_4                        or  4  or   0b0100  :  DAC4 channel selected
                AD5671R_CH_5                        or  5  or   0b0101  :  DAC5 channel selected
                AD5671R_CH_6                        or  6  or   0b0110  :  DAC6 channel selected
                AD5671R_CH_7                        or  7  or   0b0111  :  DAC7 channel selected
    @param[in]  operation
                AD5671R_CMD_NOOP                    or  0  or  (0b0000) : No operation
                AD5671R_CMD_WRITE_INPUT_N           or  1  or  (0b0001) : Write to Input Register n (depend on LDAC)
                AD5671R_CMD_UPDATE_DAC_RG_N         or  2  or  (0b0010) : Update DAC Register n with contents of Iput Register n
                AD5671R_CMD_WRITE_UPDATE_DAC_CH_N   or  3  or  (0b0011) : Write to and update DAC Channel "channel n"
                AD5671R_CMD_POWER_DOWN_UP_DAC       or  4  or  (0b0100) : Power down/ power up DAC
                AD5671R_CMD_LDAC_MASK               or  5  or  (0b0101) : Hardware LDAC mask register
                AD5671R_CMD_RESET                   or  6  or  (0b0110) : Software reset (power-on reset)
                AD5671R_CMD_INTERNAL_REFER_SETUP    or  7  or  (0b0111) : Internal reference and gain setup register
                AD5671R_CMD_READBACK_ENABLE         or  9  or  (0b1001) : Set up the readback register (readback enable)
                AD5671R_CMD_UPDATE_ALL_INPUT_RG     or 10  or  (0b1010) : Update all channels of input register simultaneously with the input data 
                AD5671R_CMD_UPDATE_ALL_INPUT_DAC_RG or 11  or  (0b1011) : Update all channels of DAC register and input register simultaneously with the input data 
    @param[out] *returnArray
                The 16-bit value representing the relationship between
                the DAC's input voltage and its output voltage.
                If 3 Dacs were selected an array of 3 uint16_t will be returned
                in alphabetical order.

*/
/**************************************************************************/
void AD5671R::readDAC(uint8_t addr, uint8_t channel, uint8_t operation, uint16_t *returnArray)
{
    uint8_t i;
    // Start I2C transmission
    Wire.beginTransmission(AD5671R_ADDR_MSB + addr);
    // Command And Channel
    i2cwrite((operation << 4) + (channel));
    Wire.endTransmission();
    Wire.requestFrom((uint8_t)(AD5671R_ADDR_MSB + addr), (uint8_t)2);

    //for (i = 0; i < countSetBits(channel); i++)
    {
        returnArray[i] = ((i2cread() << 8) | i2cread());
    }
}


/**************************************************************************/
/*!
    @brief  Power off unused channels to save energy command 0100
            Any or all DACs (DAC A to DAC D) can be powered down to the
            selected mode by setting the corresponding bits in the input
            shift register.
            In normal power consumption pins supply is 0.59 mA at 5 V
            In power-down mode, the supply current falls to 4 μA at 5 V.
    @param[in]  addr
                                                      A1    A0  (pins)    7 bit addr
                DAC_A               or  0         :   GND   GND           0x08
                DAC_B               or  1         :   GND   V             0x09
                DAC_C               or  2         :   V     GND           0x0A
                DAC_D               or  3         :   V     V             0x0B
    @param[in]  X_State (Where X is Channel)
                0: Normal Operation
                1: 1 kΩ to GND
                3: Three-State (NC)
*/
/**************************************************************************/
void AD5671R::setPowerState(uint8_t addr, 
                            uint8_t DAC7_State, uint8_t DAC6_State, 
                            uint8_t DAC5_State, uint8_t DAC4_State,
                            uint8_t DAC3_State, uint8_t DAC2_State, 
                            uint8_t DAC1_State, uint8_t DAC0_State)
{
    Wire.beginTransmission(AD5671R_ADDR_MSB + addr);

    //Power down/power up DAC command
    i2cwrite(0b01000000);

    //Select Outputs by Bit Shifting
    i2cwrite((DAC7_State << 6) + (DAC6_State << 4) + (DAC5_State << 2) + (DAC4_State));
    //Select Outputs by Bit Shifting
    i2cwrite((DAC3_State << 6) + (DAC2_State << 4) + (DAC1_State << 2) + (DAC0_State));

    Wire.endTransmission();
}


/**************************************************************************/
/*!
    @brief  LDAC MASK REGISTER command 0101
            The default value of these bits is 0; that is, the LDAC pin works
            normally. Setting any of these bits to 1 forces the selected DAC
            channel to ignore transitions on the LDAC pin, regardless of the
            state of the hardware LDAC pin. This flexibility is useful in
            applications where the user wishes to select which channels
            respond to the LDAC pin. When LDAC is set HIGH either by software
            or LDAC_PIN state, the value in the input register will be copied
            to the DAC channel.
    @param[in]  addr
                                                      A1    A0  (pins)    7 bit addr
                DAC_A               or  0         :   GND   GND           0x08
                DAC_B               or  1         :   GND   V             0x09
                DAC_C               or  2         :   V     GND           0x0A
                DAC_D               or  3         :   V     V             0x0B
    @param[in]  X_Mask (Where X is Channel)
                LDAC_NoMask         or 0          :   LDAC as  LDAC_PIN. Determined by the LDAC pin.
                LDAC_Mask           or 1          :   LDAC set HIGH.  DAC channels are updated. (DAC channels see LDAC pin as 1.)
*/
/**************************************************************************/
void AD5671R::setLDACMask(uint8_t addr,
                          uint8_t DAC7_Mask, uint8_t DAC6_Mask, 
                          uint8_t DAC5_Mask, uint8_t DAC4_Mask,
                          uint8_t DAC3_Mask, uint8_t DAC2_Mask, 
                          uint8_t DAC1_Mask, uint8_t DAC0_Mask)
{
    int mask = 0;
    Wire.beginTransmission(AD5671R_ADDR_MSB + addr);

    //Power down/power up DAC command
    i2cwrite(0b01010000);

    //Empty line (Dont care bits)
    i2cwrite(0);

    mask = (DAC7_Mask << 7) + (DAC6_Mask << 6) + (DAC5_Mask << 5) + (DAC4_Mask << 4) + \
           (DAC3_Mask << 3) + (DAC2_Mask << 2) + (DAC1_Mask << 1) + (DAC0_Mask);

    i2cwrite(mask);

    Wire.endTransmission();
}

/**************************************************************************/
/*!
    @brief  Software Reset - command 0110
            Resets the DAC to the power-on reset code. Any events
            on LDAC during a power-on reset are ignored. If the RESET
            pin is pulled low at power-up, the device does not initialize
            correctly until the pin is released.
@param[in]  addr
                                                  A1    A0  (pins)    7 bit addr
            DAC_A               or  0         :   GND   GND           0x08
            DAC_B               or  1         :   GND   V             0x09
            DAC_C               or  2         :   V     GND           0x0A
            DAC_D               or  3         :   V     V             0x0B
*/
/**************************************************************************/
void AD5671R::reset(uint8_t addr)
{
    Wire.beginTransmission(AD5671R_ADDR_MSB + addr);

    //Software reset (power-on reset)
    i2cwrite(0b01100000);

    //Empty line (Dont care bits)
    i2cwrite(0);
    i2cwrite(0x1234 << AD5671R_SHIFT);

    Wire.endTransmission();
}

/**************************************************************************/
/*!
    @brief  Software setGain - command 0111
            Setting up the internal reference and amplifier gain.
@param[in]  gain Amplifier gain setting DB2 = 
            GAIN_1   0 : amplifier gain = 1 (default)
            GAIN_2   1 : amplifier gain = 2
@param[in]  interref Internal reference setup register DB0  value
            REF_ON   0 : reference is on (default)
            REF_OFF  1 : reference is off
*/
/**************************************************************************/
void AD5671R::setGain(uint8_t addr, uint8_t gain, uint8_t interref)
{
    // check paprams
    if( (gain > 1) || (interref > 1))
    {
        //printf("gain or interref values is not valid!!!!\n\n\n");
        return;
    }

    Wire.beginTransmission(AD5671R_ADDR_MSB + addr);

    // Set gain
    i2cwrite(0b01110000);

    //Empty line (Dont care bits)
    i2cwrite(0);
    i2cwrite(gain << 2 + interref);

    Wire.endTransmission();
}
